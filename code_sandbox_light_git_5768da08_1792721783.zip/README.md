# dojunpark.github.io

My academic website: research interests, publications, background, and contact information. A minimal, responsive layout built around the content.

**GitHub Pages address:** https://dojunpark.github.io/

## Structure

- `index.html` — content and publication entries
- `css/style.css` — typography and responsive layout
- `js/main.js` — publication filters and navigation
- `images/` — profile photo

Built with HTML, CSS, and JavaScript. Content is stored directly in the HTML; no database, API, or build step is needed.

## Navigation

`/#home` · `/#about` · `/#research` · `/#background` · `/#expertise` · `/#contact`

Publications can be filtered by published papers and preprints. No URL parameters are required.

## Deployment

In the [repository](https://github.com/DojunPark/dojunpark.github.io), enable GitHub Pages under **Settings → Pages**, using the `main` branch and `/ (root)` folder. Keep `index.html` at the repository root.

## Possible additions

A downloadable CV and a Korean version are not included yet. Keep publication details and profile links up to date.
